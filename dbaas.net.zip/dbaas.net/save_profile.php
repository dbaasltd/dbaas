<?php

require 'conn.php';


$name = trim($_POST['name']);
$phone = trim($_POST['phone']);
$email = trim($_POST['email']);

$sql = "INSERT INTO `profile_downloads`(`name`,`email`,`phone`)VALUES('$name','$email','$phone')";


$exe = mysqli_query($conn,$sql);




if($exe)
{
      echo "DBaaS(UK)-Ltd.pdf";
}
else
{
     echo 0;
}



?>