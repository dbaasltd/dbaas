<?php

require 'conn.php';


$sql = "SELECT * FROM `job_postings` WHERE `status` = '1' AND `is_delete` = '0'";


$res = mysqli_query($conn,$sql);

$cnt = 1;
while($row = mysqli_fetch_array($res))
{
?>


<li class="accordion-item">
                            <a class="accordion-title" href="javascript:void(0)">
                                <i class='bx bx-chevron-down'></i>
                                <?php echo $row['job_title'];?>
                            </a>
                    
                            <div class="accordion-content">
                                <p><?php echo $row['job_short_description'];?></p>
                                <p><strong>Location:</strong> <?php echo $row['job_location'];?></p>
                               
                               
                                <p><strong>Job Type:</strong> 
                                
                                <?php
                                   echo $row['job_type']
                                ?>   
                               
                           
                            
                            
                            </p>

                                <a href="#" class="default-btn1"  data-toggle="modal" data-target="#myModal<?php echo $cnt;?>">More Info</a>
                                <a href="#" class="optional-btn" data-toggle="modal" data-target="#applyjob">Apply Now</a>
                            </div>
                        </li>


                        


<?php
$cnt++;
}
?>

<script>


            $('.accordion').find('.accordion-title').on('click', function(){
                // Adds Active Class
                $(this).toggleClass('active');
                // Expand or Collapse This Panel
                $(this).next().slideToggle('fast');
                // Hide The Other Panels
                $('.accordion-content').not($(this).next()).slideUp('fast');
                // Removes Active Class From Other Titles
                $('.accordion-title').not($(this)).removeClass('active');		
            });



</script>


