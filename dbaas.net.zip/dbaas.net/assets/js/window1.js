$(window).load(function() {
           
     
     setTimeout(function(){
     jQuery("#lz_chat_text").val("");
 },1500);



   });

