$(window).load(function() {

    setTimeout(function(){
    jQuery("#lz_chat_text").val("");
},1500); 
           
    setTimeout(function(){
         if(!jQuery("#lz_overlay_chat").is(":visible")){
 
         
 jQuery("#livezilla_wm").trigger("click");

 }
 
     },1000); 

    
    
   });

 

  
 