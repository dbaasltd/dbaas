<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';
error_reporting(E_ALL);
require 'conn.php';


$name = trim($_POST['name']);
$email = trim($_POST['email']);
$phone = trim($_POST['phone']);
$location = trim($_POST['location']);
$message = trim($_POST['message']);


$designation = trim($_POST['designation']);

$file_name = $_FILES['resume']['name'];

$file_dataxx = explode(".",$file_name);

$file_ext = $file_dataxx[1];

$file_name1 = time().".".$file_ext;

if(move_uploaded_file($_FILES['resume']['tmp_name'],"dbaas/public/uploads/career/".$file_name1))
{

  $sql = "INSERT INTO `careers`(`name`,`email`,`phone`,`designation`,`location`,`message`,`resume`,`status`)VALUES('$name','$email','$phone','$designation','$location','$message','$file_name1','1')";


   $exe = mysqli_query($conn,$sql);


$subject = "Dbaas Contact Form - Careers Message";
$message='<html>
          <body>
          <div style="width: 75%;padding: 12px;color: #9F430A;">
       
          <div class="logo" style="text-align: left;">
          <img width="20%" height="8%" src="https://www.innoblitz.global/demo/dbaas-v1/assets/img/dbass-logo.png">
         </div>
        
  <table  style="width:100%; color: #333; padding: 12px; font-family: sans-serif; font-size: 14px;line-height: 25px;letter-spacing: 1px; width: 100%;text-align: left;margin:0 auto;line-height:2">
 <tr>
 <td width="100%" style="margin-left:50px; color:#333;" ><span style="color:#333;"><strong>Name</strong></span> :'.$name.'</td>
 </tr>
 <tr>
 <td width="100%" style="margin-left:50px; color:#333;"><span style="color:#333;"><strong>Email</strong></span> :'.$email.'</td>
 </tr>
 <tr>
 <td width="100%" style="margin-left:50px"style="margin-left:50px; color:#333;"><span style="color:#333;"><strong>Contact Number</strong></span> :'.$phone.'</td>
 </tr>
 <tr>
 <td width="100%" style="margin-left:50px; color:#333;"><span style="color:#333;"><strong>Designation</strong></span> :'.$designation.'</td>
 </tr>
 <tr>
 <td width="100%" style="margin-left:50px; color:#333;"><span style="color:#333;"><strong>Location</strong></span> :'.$location.'</td>
 </tr>
 <tr>
 <td width="100%" style="margin-left:50px; color:#333;"><span style="color:#333;"><strong>Message</strong></span> :'.$message.'</td>
 </tr>

 
  </table>
  </div>
  </body>
  </html>';
 


  
  // Instantiation and passing `true` enables exceptions
  $mail = new PHPMailer(true);
  
  try {
      //Server settings
     // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
     // $mail->isSMTP();                                            // Send using SMTP
      $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
      $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
      $mail->Username   = 'sauravdaga.innoblitz@gmail.com';                     // SMTP username
      $mail->Password   = 'InnoblitzMay@2020';                               // SMTP password
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
      $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
  
      //Recipients
      $mail->setFrom('sauravdaga.innoblitz@gmail.com', 'Saurav Daga');

     
      $mail->addAddress("hr@dbaasltd.co.uk", "HR");
      //$mail->addAddress("sauravdaga.innoblitz@gmail.com", "Saurav Daga");
     
     //$mail->AddAttachment($_FILES['resume']['tmp_name'],$file_name1);
     
  
      $mail->isHTML(true);                                
      $mail->Subject = 'Dbaas Careers Form';
      $mail->Body    = $message;
      $mail->AddAttachment("dbaas/public/uploads/career/".$file_name1,$file_name1);
  
      $mail->send();
      echo 1;
  } catch (Exception $e) {
      echo $e;
  }



  $mail = new PHPMailer(true);

  try {
    //Server settings
   // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
   // $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'sauravdaga.innoblitz@gmail.com';                     // SMTP username
    $mail->Password   = 'InnoblitzMay@2020';                               // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('sauravdaga.innoblitz@gmail.com', 'Saurav Daga');

   
    //$mail->addAddress("subramaniyaninnoblitz@gmail.com", "Admin");
    $mail->addAddress($email, $name);
   
    $message = 'Dear Candidate,<br><br>
    Thank you for applying for the following job:<br>
    Title: '.$designation.'<br><br>
    We have sent the recruiter a summary of your CV and covering letter.<br>
    
    If they wish to proceed with your application they will contact you directly. Unsuccessful applications may not receive a response from the recruiter.<br>
    
    We wish you luck with your application!<br>
    
    PLEASE DO NOT REPLY TO THIS EMAIL<br>';
   

    $mail->isHTML(true);                                
    $mail->Subject = 'Dbaas Careers';
    $mail->Body    = $message;
    

    $mail->send();
    echo 1;
} catch (Exception $e) {
    echo $e;
}



}
else
{
    echo 0;
}


?>