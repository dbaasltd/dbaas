<?php
date_default_timezone_set('Asia/Kolkata');
$conn = mysqli_connect("localhost","dbass_usr","RDqimMupzJ6T","dbaas_cms");
//$conn = mysqli_connect("localhost","root","","dbaas");



?>