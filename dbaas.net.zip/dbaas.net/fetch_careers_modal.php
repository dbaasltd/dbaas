<?php

require 'conn.php';


$sql = "SELECT * FROM `job_postings` WHERE `status` = '1' AND `is_delete` = '0'";


$res = mysqli_query($conn,$sql);

$cnt = 1;
while($row = mysqli_fetch_array($res))
{
?>




                        <div class="modal fade" id="myModal<?php echo $cnt;?>" role="dialog">
            <div class="modal-dialog modal-lg">
            
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"> <?php echo $row['job_title'];?></h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  
                </div>
                <div class="modal-body" style="padding:0px 30px;">
            
                <?php echo $row['job_info'];?>
                         
                

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
              
            </div>
          </div>


<?php
$cnt++;
}
?>



